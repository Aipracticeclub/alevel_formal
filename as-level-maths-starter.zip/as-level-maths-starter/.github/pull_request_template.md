## Change
What works differently now?

## Affected roles
Which module owners need to review? Did the API or database format change?

## Verification
- [ ] `npm test` passed (or explain what failed)
- [ ] Relevant browser checks completed (or state what was not checked)

## Handoff
Any teammate action, migration, or server setting required?
