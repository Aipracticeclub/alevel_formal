---
name: Club task
about: One feature, bug, or feedback item
title: ""
labels: ""
assignees: ""
---

Role / owner:

What should change:

Success means:

Likely files / modules:

Related teammates:
